<?php

$con= mysqli_connect("localhost","root","","voting_system");
if(!$con){
   die(mysqli_error($con));
}

?>
